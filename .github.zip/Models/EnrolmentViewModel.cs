﻿namespace RaceDayMVC.Models
{
    public class EnrolmentViewModel
    {
        public int EnrolmentID { get; set; }

        public DateTime? EnrolmentDate { get; set; }

        public string EnrolmentStatus { get; set; } = "";

        public string ParticipantName { get; set; } = "";

        public string ParticipantEmail { get; set; } = "";

        public string EventName { get; set; } = "";

        public string CategoryName { get; set; } = "";
    }
}