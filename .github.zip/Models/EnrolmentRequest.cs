﻿namespace RaceDayMVC.Models
{
    public class EnrolmentRequest
    {
        public int? EventID { get; set; }

        public int? CategoryID { get; set; }
    }
}