﻿using System.ComponentModel.DataAnnotations;

namespace RaceDayMVC.Models
{
    public class AddResultViewModel
    {
        [Required]
        [Display(Name = "Participant Enrolment")]
        public int? EnrolmentID { get; set; }

        [Required]
        [Display(Name = "Finishing Time")]
        public TimeSpan? FinishTime { get; set; }

        [Required]
        [Range(1, int.MaxValue)]
        [Display(Name = "Finishing Position")]
        public int? Position { get; set; }

        public List<EnrolmentViewModel> AvailableEnrolments { get; set; }
            = new List<EnrolmentViewModel>();
    }
}