﻿using System.ComponentModel.DataAnnotations;

namespace RaceDayMVC.Models
{
    public class ParticipantProfileViewModel
    {
        [Required]
        [DataType(DataType.Date)]
        public DateTime? DateOfBirth { get; set; }

        [Required]
        public string Gender { get; set; } = "";

        [Required]
        [StringLength(150)]
        public string Address { get; set; } = "";

        [Required]
        [StringLength(50)]
        public string City { get; set; } = "";
    }
}