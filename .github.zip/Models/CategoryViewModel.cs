﻿namespace RaceDayMVC.Models
{
    public class CategoryViewModel
    {
        public int CategoryID { get; set; }

        public int? EventID { get; set; }

        public string? CategoryName { get; set; }

        public string? CategoryType { get; set; }

        public string? MinValue { get; set; }

        public string? MaxValue { get; set; }
    }
}