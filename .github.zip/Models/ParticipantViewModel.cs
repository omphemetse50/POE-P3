﻿
namespace RaceDayMVC.Models
{
    public class ParticipantViewModel
    {
        public int ParticipantID { get; set; }

        public int UserID { get; set; }

        public string Name { get; set; } = "";

        public string Email { get; set; } = "";

        public string PhoneNumber { get; set; } = "";

        public DateTime? DateOfBirth { get; set; }

        public string Gender { get; set; } = "";

        public string Address { get; set; } = "";

        public string City { get; set; } = "";
    }
}
