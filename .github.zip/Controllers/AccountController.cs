﻿
using Microsoft.AspNetCore.Mvc;
using RaceDayMVC.Models;
using RaceDayMVC.Services;
using System.Text.Json;

namespace RaceDayMVC.Controllers
{
    public class AccountController : Controller
    {
        private readonly ApiService _apiService;

        public AccountController(ApiService apiService)
        {
            _apiService = apiService;
        }

        // LOGIN PAGE
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        // PROCESS LOGIN
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            try
            {
                var response = await _apiService.LoginAsync(model);

                if (!response.IsSuccessStatusCode)
                {
                    ModelState.AddModelError("",
                        "Invalid email or password.");

                    return View(model);
                }

                // CAPTURE API SESSION COOKIE
                if (response.Headers.TryGetValues(
                    "Set-Cookie", out var cookieValues))
                {
                    var apiCookie = cookieValues.FirstOrDefault();

                    if (!string.IsNullOrEmpty(apiCookie))
                    {
                        var cookiePair = apiCookie.Split(';', 2)[0];

                        HttpContext.Session.SetString(
                            "ApiSessionCookie",
                            cookiePair
                        );
                    }
                }

                // READ LOGIN RESPONSE
                var content =
                    await response.Content.ReadAsStringAsync();

                using var document = JsonDocument.Parse(content);

                var user = document.RootElement;

                int userID = user.GetProperty("userID").GetInt32();

                string name =
                    user.GetProperty("name").GetString() ?? "";

                string role =
                    user.GetProperty("role").GetString() ?? "";

                // TEMPORARY ROLE DIAGNOSTIC
                TempData["DebugRole"] = "LOGIN ROLE: " + role;

                // SAVE USER INFORMATION IN MVC SESSION
                HttpContext.Session.SetInt32("UserID", userID);

                HttpContext.Session.SetString("UserName", name);

                HttpContext.Session.SetString("UserRole", role);

                // REDIRECT ACCORDING TO ROLE
                if (role.Equals(
                    "Organiser",
                    StringComparison.OrdinalIgnoreCase))
                {
                    return RedirectToAction(
                        "Dashboard", "Organiser");
                }

                return RedirectToAction(
                    "Index", "Participant");
            }
            catch
            {
                ModelState.AddModelError("",
                    "Unable to connect to RaceDay. Please try again.");

                return View(model);
            }
        }

        // REGISTRATION PAGE
        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        // PROCESS REGISTRATION
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            try
            {
                var response =
                    await _apiService.RegisterAsync(model);

                if (!response.IsSuccessStatusCode)
                {
                    ModelState.AddModelError("",
                        "Registration failed. Your email may already be registered.");

                    return View(model);
                }

                TempData["SuccessMessage"] =
                    "Registration successful! Please log in.";

                return RedirectToAction("Login");
            }
            catch
            {
                ModelState.AddModelError("",
                    "Unable to connect to RaceDay. Please try again.");

                return View(model);
            }
        }

        // LOGOUT
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();

            return RedirectToAction("Login", "Account");
        }
    }
}
