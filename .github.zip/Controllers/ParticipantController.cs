﻿using Microsoft.AspNetCore.Mvc;
using RaceDayMVC.Models;
using RaceDayMVC.Services;

namespace RaceDayMVC.Controllers
{
    public class ParticipantController : Controller
    {
        // 1.  ApiService field
        private readonly ApiService _apiService;

        // 2.  constructor 
        public ParticipantController(ApiService apiService)
        {
            _apiService = apiService;
        }

        // 3. Index method 
        public async Task<IActionResult> Index()
        {
            int? userID = HttpContext.Session.GetInt32("UserID");

            if (userID == null)
            {
                return RedirectToAction("Login", "Account");
            }

            ViewBag.UserName = HttpContext.Session.GetString("UserName");

            var events = await _apiService.GetEventsAsync();

            return View(events);
        }

        // VIEW EVENT DETAILS
        public async Task<IActionResult> Details(int id)
        {
            int? userID = HttpContext.Session.GetInt32("UserID");

            if (userID == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var eventItem = await _apiService.GetEventAsync(id);

            if (eventItem == null)
            {
                return NotFound("Event not found.");
            }

            var allCategories = await _apiService.GetCategoriesAsync();

            var eventCategories = allCategories
                .Where(c => c.EventID == id)
                .ToList();

            var viewModel = new EventDetailsViewModel
            {
                Event = eventItem,
                Categories = eventCategories
            };

            return View(viewModel);
        }


        // PARTICIPANT PROFILE PAGE
        [HttpGet]
        public IActionResult Profile()
        {
            int? userID = HttpContext.Session.GetInt32("UserID");

            if (userID == null)
            {
                return RedirectToAction("Login", "Account");
            }

            return View(new ParticipantProfileViewModel());
        }

        // SAVE PARTICIPANT PROFILE
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Profile(
            ParticipantProfileViewModel model)
        {
            int? userID = HttpContext.Session.GetInt32("UserID");

            if (userID == null)
            {
                return RedirectToAction("Login", "Account");
            }

            if (!ModelState.IsValid)
            {
                return View(model);
            }

            string? apiCookie =
                HttpContext.Session.GetString("ApiSessionCookie");

            if (string.IsNullOrEmpty(apiCookie))
            {
                ModelState.AddModelError("",
                    "API session was not saved. Please log out and log in again.");

                return View(model);
            }

            try
            {
                var response =
                    await _apiService.CreateParticipantProfileAsync(
                        model, apiCookie);

                if (!response.IsSuccessStatusCode)
                {
                    var error = await response.Content.ReadAsStringAsync();

                    ModelState.AddModelError("", error);
                    return View(model);
                }

                TempData["SuccessMessage"] =
                    "Your participant profile has been saved!";

                return RedirectToAction("Index");
            }
            catch
            {
                ModelState.AddModelError("",
                    "Unable to connect to RaceDay. Please try again.");

                return View(model);
            }
        }

        // ENROL IN AN EVENT
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Enrol(EnrolmentRequest model)
        {
            int? userID = HttpContext.Session.GetInt32("UserID");

            if (userID == null)
            {
                return RedirectToAction("Login", "Account");
            }

            if (model.EventID == null)
            {
                return BadRequest("Event ID is required.");
            }

            string? apiCookie =
                HttpContext.Session.GetString("ApiSessionCookie");

            if (string.IsNullOrEmpty(apiCookie))
            {
                return RedirectToAction("Login", "Account");
            }

            try
            {
                var response = await _apiService.EnrolParticipantAsync(
                    model, apiCookie);

                if (!response.IsSuccessStatusCode)
                {
                    var error = await response.Content.ReadAsStringAsync();

                    TempData["ErrorMessage"] = error;

                    return RedirectToAction(
                        "Details",
                        new { id = model.EventID }
                    );
                }

                TempData["SuccessMessage"] =
                    "You have successfully enrolled in this event!";

                return RedirectToAction(
                    "Details",
                    new { id = model.EventID }
                );
            }
            catch
            {
                TempData["ErrorMessage"] =
                    "Unable to connect to RaceDay. Please try again.";

                return RedirectToAction(
                    "Details",
                    new { id = model.EventID }
                );
            }
        }
        // VIEW PARTICIPANT'S OWN RESULTS
        public async Task<IActionResult> MyResults()
        {
            int? userID = HttpContext.Session.GetInt32("UserID");

            string? role = HttpContext.Session.GetString("UserRole");

            if (userID == null || role != "Participant")
            {
                return RedirectToAction("Login", "Account");
            }

            string? apiCookie =
                HttpContext.Session.GetString("ApiSessionCookie");

            if (string.IsNullOrEmpty(apiCookie))
            {
                return RedirectToAction("Login", "Account");
            }

            ViewBag.UserName =
                HttpContext.Session.GetString("UserName");

            var results = await _apiService.GetMyResultsAsync(apiCookie);

            return View(results);
        }

    }
}