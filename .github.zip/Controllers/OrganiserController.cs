﻿
using Microsoft.AspNetCore.Mvc;
using RaceDayMVC.Services;
using RaceDayMVC.Models;

namespace RaceDayMVC.Controllers
{
    public class OrganiserController : Controller
    {
        private readonly ApiService _apiService;

        public OrganiserController(ApiService apiService)
        {
            _apiService = apiService;
        }

        // CHECK ORGANISER LOGIN
        private bool IsOrganiser()
        {
            int? userID = HttpContext.Session.GetInt32("UserID");
            string? role = HttpContext.Session.GetString("UserRole");

            return userID != null &&
                   string.Equals(role, "Organiser",
                       StringComparison.OrdinalIgnoreCase);
        }

        // GET API SESSION COOKIE
        private string? GetApiCookie()
        {
            return HttpContext.Session.GetString("ApiSessionCookie");
        }

        // ORGANISER DASHBOARD
        public async Task<IActionResult> Dashboard()
        {
            if (!IsOrganiser())
                return RedirectToAction("Login", "Account");

            ViewBag.UserName =
                HttpContext.Session.GetString("UserName");

            var events = await _apiService.GetEventsAsync();

            return View(events);
        }

        // CREATE EVENT - GET
        [HttpGet]
        public IActionResult CreateEvent()
        {
            if (!IsOrganiser())
                return RedirectToAction("Login", "Account");

            return View();
        }

        // CREATE EVENT - POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateEvent(EventViewModel model)
        {
            if (!IsOrganiser())
                return RedirectToAction("Login", "Account");

            if (!ModelState.IsValid)
                return View(model);

            var response = await _apiService.CreateEventAsync(
                model, GetApiCookie());

            if (!response.IsSuccessStatusCode)
            {
                ModelState.AddModelError("",
                    "Unable to create the event. Please check your details.");

                return View(model);
            }

            TempData["SuccessMessage"] = "Event created successfully!";

            return RedirectToAction("Dashboard");
        }

        // EDIT EVENT - GET
        [HttpGet]
        public async Task<IActionResult> EditEvent(int id)
        {
            if (!IsOrganiser())
                return RedirectToAction("Login", "Account");

            var eventItem = await _apiService.GetEventAsync(id);

            if (eventItem == null)
                return NotFound();

            return View(eventItem);
        }

        // EDIT EVENT - POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditEvent(
            int id, EventViewModel model)
        {
            if (!IsOrganiser())
                return RedirectToAction("Login", "Account");

            if (!ModelState.IsValid)
                return View(model);

            var response = await _apiService.UpdateEventAsync(
                id, model, GetApiCookie());

            if (!response.IsSuccessStatusCode)
            {
                ModelState.AddModelError("",
                    "Unable to update the event. Please try again.");

                return View(model);
            }

            TempData["SuccessMessage"] = "Event updated successfully!";

            return RedirectToAction("Dashboard");
        }

        // DELETE EVENT - POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteEvent(int id)
        {
            if (!IsOrganiser())
                return RedirectToAction("Login", "Account");

            var response = await _apiService.DeleteEventAsync(
                id, GetApiCookie());

            if (response.IsSuccessStatusCode)
            {
                TempData["SuccessMessage"] = "Event deleted successfully!";
            }
            else
            {
                TempData["ErrorMessage"] =
                    "Unable to delete this event. Related records may exist.";
            }

            return RedirectToAction("Dashboard");
        }


        // VIEW ALL PARTICIPANTS
        public async Task<IActionResult> Participants()
        {
            if (!IsOrganiser())
                return RedirectToAction("Login", "Account");

            var participants = await _apiService.GetParticipantsAsync();

            return View(participants);
        }
        // VIEW ALL ENROLMENTS
        public async Task<IActionResult> Enrolments()
        {
            if (!IsOrganiser())
                return RedirectToAction("Login", "Account");

            var enrolments = await _apiService.GetEnrolmentsAsync();

            return View(enrolments);
        }

        // GET: CREATE RESULT
        [HttpGet]
        public async Task<IActionResult> CreateResult()
        {
            if (!IsOrganiser())
                return RedirectToAction("Login", "Account");

            var enrolments =
                await _apiService.GetAvailableEnrolmentsForResultsAsync(
                    GetApiCookie());

            var model = new AddResultViewModel
            {
                AvailableEnrolments = enrolments
            };

            return View(model);
        }


        // POST: CREATE RESULT
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateResult(AddResultViewModel model)
        {
            if (!IsOrganiser())
                return RedirectToAction("Login", "Account");

            var apiCookie = GetApiCookie();

            if (string.IsNullOrEmpty(apiCookie))
            {
                TempData["ErrorMessage"] = "Your session has expired. Please log in again.";
                return RedirectToAction("Login", "Account");
            }

            if (!ModelState.IsValid)
            {
                model.AvailableEnrolments =
                    await _apiService.GetAvailableEnrolmentsForResultsAsync(apiCookie);

                return View(model);
            }

            var response = await _apiService.CreateResultAsync(
                model,
                apiCookie);

            if (response.IsSuccessStatusCode)
            {
                TempData["SuccessMessage"] = "Participant result recorded successfully!";

                return RedirectToAction("Results");
            }

            var errorMessage = await response.Content.ReadAsStringAsync();

            ModelState.AddModelError("",
                string.IsNullOrWhiteSpace(errorMessage)
                    ? "Unable to record the result."
                    : errorMessage);

            model.AvailableEnrolments =
                await _apiService.GetAvailableEnrolmentsForResultsAsync(apiCookie);

            return View(model);
        }

        // VIEW ALL RESULTS
        public async Task<IActionResult> Results()
        {
            if (!IsOrganiser())
                return RedirectToAction("Login", "Account");

            var results = await _apiService.GetResultsAsync();

            return View(results);
        }

        // CONFIRM ENROLMENT 
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ConfirmEnrolment(int id)
        {
            if (!IsOrganiser())
                return RedirectToAction("Login", "Account");

            var response = await _apiService.ConfirmEnrolmentAsync(
                id, GetApiCookie());

            if (response.IsSuccessStatusCode)
            {
                TempData["SuccessMessage"] =
                    "Enrolment confirmed successfully!";
            }
            else
            {
                var errorMessage = await response.Content.ReadAsStringAsync();

                TempData["ErrorMessage"] =
                    $"Unable to confirm enrolment: {errorMessage}";
            }

            return RedirectToAction("Enrolments");
        }
    }
}
